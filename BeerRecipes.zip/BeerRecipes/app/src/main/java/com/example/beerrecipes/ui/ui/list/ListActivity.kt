package com.example.beerrecipes.ui.ui.list

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ListActivity :AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}