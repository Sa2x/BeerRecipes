package com.example.beerrecipes.ui.navigator

interface AppNavigator{

}