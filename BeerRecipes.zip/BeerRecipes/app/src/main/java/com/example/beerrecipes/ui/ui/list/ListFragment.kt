package com.example.beerrecipes.ui.ui.list

import androidx.fragment.app.Fragment
import com.example.beerrecipes.ui.model.Beer

class ListFragment: Fragment(), ListScreen{
    override fun showBeers(beers: List<Beer>) {
        TODO("Not yet implemented")
    }

}