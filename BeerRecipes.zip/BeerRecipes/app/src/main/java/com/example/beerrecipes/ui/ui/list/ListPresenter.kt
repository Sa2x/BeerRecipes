package com.example.beerrecipes.ui.ui.list

import com.example.beerrecipes.ui.ui.Presenter

class ListPresenter(): Presenter<ListScreen>() {

}