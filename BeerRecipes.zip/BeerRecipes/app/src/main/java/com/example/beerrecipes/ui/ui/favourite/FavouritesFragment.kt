package com.example.beerrecipes.ui.ui.favourite

import androidx.fragment.app.Fragment
import com.example.beerrecipes.ui.model.Beer

class FavouritesFragment :Fragment(), FavouritesScreen {
    override fun showFavourites(favourites: List<Beer>) {
        TODO("Not yet implemented")
    }

}