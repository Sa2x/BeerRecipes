package com.example.beerrecipes.ui.navigator

class AppNavigatorImpl : AppNavigator {

}