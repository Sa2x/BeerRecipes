package com.example.beerrecipes.ui.ui.favourite

import com.example.beerrecipes.ui.ui.Presenter

class FavouritesPresenter() :Presenter<FavouritesScreen>(){

}