package com.example.beerrecipes.ui

class DIReturn() {
}