package com.example.beerrecipes.ui.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert

@Dao
interface FavouriteBeerDao {


    fun getAll():List<BeerModel>

    @Insert
    fun insert(beer:BeerModel)

    @Delete
    fun delete(beer:BeerModel)
}
