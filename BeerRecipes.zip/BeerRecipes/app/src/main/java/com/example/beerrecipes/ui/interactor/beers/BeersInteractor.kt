package com.example.beerrecipes.ui.interactor.beers

import com.example.beerrecipes.ui.data.BeerModel
import com.example.beerrecipes.ui.data.FavouriteBeerRepository
import com.example.beerrecipes.ui.model.Beer
import com.example.beerrecipes.ui.network.BeerApi
import java.math.BigDecimal
import javax.inject.Inject

class BeersInteractor @Inject constructor(private var beerApi: BeerApi ,private var beerRepo:FavouriteBeerRepository) {

    fun getBeers(page:BigDecimal,limit:BigDecimal){
        try{
            val beersQueryCall = beerApi.beerList(page,limit)
            val response = beersQueryCall?.execute()
        }
        catch(e:Exception){

        }
    }

    fun searchBeers(BeerQuery: String){

    }

    fun getBeerwithId(id: BigDecimal){
        try{
            val beerQueryCall = beerApi.beerFindById(id)
            val response = beerQueryCall?.execute()
        }
        catch(e:Exception){

        }
    }
    fun addBeerToFavourite(beer : Beer){
            beerRepo.addOne(BeerModel(beer.id!!.toLong(),beer.name,beer.imageurl))
    }

    fun removeBeerToFavourite(beer:Beer){
        beerRepo.deleteOne(BeerModel(beer.id!!.toLong(),beer.name,beer.imageurl))
    }
    fun getFavouriteBeers(){
        beerRepo.getAll()
    }
}