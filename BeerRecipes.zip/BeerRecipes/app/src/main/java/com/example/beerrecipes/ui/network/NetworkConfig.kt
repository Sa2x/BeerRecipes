package com.example.beerrecipes.ui.network

object NetworkConfig {
    const val API_ENDPOINT_ADDRESS = "https://api.punkapi.com/v2/"
}