package com.example.beerrecipes.ui.network

import com.example.beerrecipes.ui.model.Beer
import retrofit2.http.*
import java.math.BigDecimal

interface BeerApi {
    /**
     * Find a list from the data source.
     *
     * @param page Page id
     * @param perPage Perpage count
     * @return Call<Beer>
    </Beer> */

    @GET("beers")
    fun beerList(
        @Query("page") page: BigDecimal?, @Query("per_page") perPage: BigDecimal?
    ): retrofit2.Call<List<Beer>?>?

    /**
     * Find a model instance by id from the data source.
     *
     * @param id Model id
     * @return Call<Beer>
    </Beer> */
    @GET("beers/{id}")
    fun beerFindById(
            @Path("id") id: BigDecimal?
    ): retrofit2.Call<Beer?>?
}