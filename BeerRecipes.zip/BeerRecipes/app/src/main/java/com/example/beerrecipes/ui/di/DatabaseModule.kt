package com.example.beerrecipes.ui.di

import android.content.Context
import com.example.beerrecipes.ui.DIReturn
import com.example.beerrecipes.ui.data.FavouriteBeerDao
import com.example.beerrecipes.ui.data.FavouriteBeerDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import javax.inject.Singleton


@InstallIn(SingletonComponent::class)
@Module
object DatabaseModule {

    private val applicationScope = CoroutineScope(SupervisorJob())

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext appContext: Context):FavouriteBeerDatabase{
        return FavouriteBeerDatabase.getDatabase(appContext, applicationScope)
    }

    @Provides
    fun provideBeerDao(favouriteBeerDB: FavouriteBeerDatabase): FavouriteBeerDao=favouriteBeerDB.favouriteBeerDao()
}