package com.example.beerrecipes.ui.ui.list

import com.example.beerrecipes.ui.model.Beer

interface ListScreen {
    fun showBeers(beers:List<Beer>)}